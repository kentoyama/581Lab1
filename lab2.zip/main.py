#!/usr/bin/env pybricks-micropython

from pybricks import ev3brick as brick
from pybricks.ev3devices import (Motor, TouchSensor, ColorSensor,
                                 InfraredSensor, UltrasonicSensor, GyroSensor)
from pybricks.parameters import (Port, Stop, Direction, Button, Color,
                                 SoundFile, ImageFile, Align)
from pybricks.tools import print, wait, StopWatch
from pybricks.robotics import DriveBase

# Write your program here
right = Motor(Port.B, Direction.COUNTERCLOCKWISE)
left = Motor(Port.C, Direction.COUNTERCLOCKWISE)
ultrasonicSensor = UltrasonicSensor(Port.S1)
touchRight = TouchSensor(Port.S2)
touchLeft = TouchSensor(Port.S4)
gyro = GyroSensor(Port.S3, Direction.CLOCKWISE)
stop_type = Stop.BRAKE
#lsjlfjslkj

#Step 1: Run straight until sensor senses wall (<30cm)
while touchRight.pressed() == False and touchLeft.pressed() == False:
    right.run(300)
    left.run(300)
right.stop()
left.stop()
wait(1000)
brick.sound.beep()

#Step 1-2: After runs into wall, move back a so not too close to wall
right.run(-200)
left.run(-200)
wait(750)
right.stop()
left.stop()

#Step 2: After wall is sensed turn 90 degrees

right.run_angle(200, -210, Stop.BRAKE, False)
left.run_angle(200, 210, Stop.BRAKE, True)
wait(1000)

#Step 3: Drive alongside wall, within 30cm
    #Keep within 10 - 20cm, if above 10 --> 20, if hits 20 --> 10
right.run(200)
left.run(200)

while ultrasonicSensor.distance() < 300:
    if ultrasonicSensor.distance() < 110: 
        right.run(200)
        left.run(235)
    if ultrasonicSensor.distance() > 210:
        right.run(235)
        left.run(200)

#Step 4: When bend is sensed, turn accordingly

    if ultrasonicSensor.distance() < 55:
        right.run(200)
        left.run(320)
    if ultrasonicSensor.distance() > 255:
        right.run(300)
        left.run(210)



#Step 5: When wall to left is gone turn 90 degrees
right.run(200)
left.run(200)
wait(1500)
right.stop()
left.stop()
current_angle = gyro.angle()
right.run_angle(250, 2.2 * current_angle, Stop.BRAKE, False)
left.run_angle(250, -2.2 * current_angle, Stop.BRAKE, True)
brick.sound.beep()


#Step 6: Run 0.7 meters to end point
#1432.4 rotations
 
right.run_time(400, 4400, Stop.BRAKE, False)
left.run_time(400, 4400, Stop.BRAKE, True)
brick.sound.beep()
